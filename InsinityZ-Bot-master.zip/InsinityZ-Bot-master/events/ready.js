module.exports = client => {
 console.log("InsinityZ'Bot en ligne !");
  client.user.setActivity('.help',{type:'LISTENING'})
};
 //on ou off
