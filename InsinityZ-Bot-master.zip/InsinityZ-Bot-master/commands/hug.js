const Discord = require('discord.js');
exports.run = (client, message, args) => {
  let user = message.mentions.users.first();
  let nb = Math.floor((Math.random() * 17) + 1);
  if (message.mentions.users.size < 1) return message.reply("vous devez mentionner quelqu'un pour le hug.").catch(console.error);
    if (nb == 1) {
   msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442055795723730944/hug1.gif')
    message.channel.send(msg)
  }
  if (nb == 2) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442055876355031070/hug7.gif')
    message.channel.send(msg)
  }
  if (nb == 3) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442055926455861269/hug9.gif')
    message.channel.send(msg)
  }
  if (nb == 4) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442056046941306881/hug8.gif')
    message.channel.send(msg)
  }
  if (nb == 5) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442056056995315713/hug5.gif')
    message.channel.send(msg)
  }
  if (nb == 6) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442056059537063936/hug3.gif')
    message.channel.send(msg)
  }
  if (nb == 7) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442056085705064468/hug11.gif')
    message.channel.send(msg)
  }
  if (nb == 8) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442056087202431021/hug6.gif')
    message.channel.send(msg)
  }
  if (nb == 9) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442056087953211412/hug12.gif')
    message.channel.send(msg)
  }
  if (nb == 10) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442717849643909121/hug10.gif')
    message.channel.send(msg)
  }
  if (nb == 11) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442718011783118849/hug15.gif')
    message.channel.send(msg)
  }
  if (nb == 12) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442718105094062080/hug14.gif')
    message.channel.send(msg)
  }
  if (nb == 13) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442718357469397023/hug4.gif')
    message.channel.send(msg)
  }
  if (nb == 14) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442718531914563585/hug13.gif')
    message.channel.send(msg)
  }
  if (nb == 15) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('')
    message.channel.send(msg)
  }
  if (nb == 16) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442719490833121281/hug16.gif')
    message.channel.send(msg)
  }
  if (nb == 17) {
  msg = new Discord.RichEmbed()
    .setTitle(`<:calin:442062827402821662> ${user.username}, vous avez reçu un câlin de ${message.author.username}`)
    .setColor('RANDOM')
    .setImage('https://cdn.discordapp.com/attachments/442055343544074240/442719523624321024/hug17.gif')
    message.channel.send(msg)
  }

}
  exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: [],
    permLevel: 0
  };

  exports.help = {
    name: 'hug',
    description: 'Callin !',
    usage: 'hug [mention]'
  }
