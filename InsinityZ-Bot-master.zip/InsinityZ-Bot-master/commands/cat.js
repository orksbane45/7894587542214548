const Discord = require('discord.js');
exports.run = function(client, message, args) {
  let nb = Math.floor((Math.random() * 25) + 1);
  if (nb == 1) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444105843462504459/cat1.jpg')
    message.channel.send(msg);
  }
  if (nb == 2) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444105864895397889/cat2.jpg')
    message.channel.send(msg);
  }
  if (nb == 3) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444105872306864130/cat3.jpg')
    message.channel.send(msg);
  }
  if (nb == 4) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444105879202037770/cat4.jpg')
    message.channel.send(msg);
  }
  if (nb == 5) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106032659169282/cat5.jpg')
    message.channel.send(msg);
  }
  if (nb == 6) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106037197537303/cat6.jpg')
    message.channel.send(msg);
  }
  if (nb == 7) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106042675298314/cat7.jpg')
    message.channel.send(msg);
  }
  if (nb == 8) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106048375357440/cat8.jpg')
    message.channel.send(msg);
  }
  if (nb == 9) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106054079479808/cat9.jpg')
    message.channel.send(msg);
  }
  if (nb == 10) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106061264191509/cat10.jpg')
    message.channel.send(msg);
  }
  if (nb == 11) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106073511559168/cat12.jpg')
    message.channel.send(msg);
  }
  if (nb == 12) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106074174259201/cat13.jpg')
    message.channel.send(msg);
  }
  if (nb == 13) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106079887032320/cat14.jpg')
    message.channel.send(msg);
  }
  if (nb == 14) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106081032077324/cat15.jpg')
    message.channel.send(msg);
  }
  if (nb == 15) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106084312023060/cat16.jpg')
    message.channel.send(msg);
  }
  if (nb == 16) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106090427449365/cat17.jpg')
    message.channel.send(msg);
  }
  if (nb == 17) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106092327337984/cat18.jpg')
    message.channel.send(msg);
  }
  if (nb == 18) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106092847562772/cat19.jpg')
    message.channel.send(msg);
  }
  if (nb == 19) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106099629752320/cat21.jpg')
    message.channel.send(msg);
  }
  if (nb == 20) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106097947836417/cat20.jpg')
    message.channel.send(msg);
  }
  if (nb == 21) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106107905114113/cat22.jpg')
    message.channel.send(msg);
  }
  if (nb == 22) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106112137035777/cat23.jpg')
    message.channel.send(msg);
  }
  if (nb == 23) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106133930639360/cat27.jpg')
    message.channel.send(msg);
  }
  if (nb == 24) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106135059038219/cat26.jpg')
    message.channel.send(msg);
  }
  if (nb == 25) {
     msg = new Discord.RichEmbed()
     .setColor('RANDOM')
     .setImage('https://cdn.discordapp.com/attachments/443889393992728576/444106154327539712/cat28.jpg')
    message.channel.send(msg);
  }


}

      exports.conf = {
        enabled: true,
        guildOnly: false,
        aliases: [],
        permLevel: 0
      };

      exports.help = {
        name: 'cat',
        description: 'null',
        usage: 'cat'
      }
